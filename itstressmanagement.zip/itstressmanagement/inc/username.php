<?php
session_start();
$uname=$_SESSION['user'];
//echo"hello";

//		 echo"<script> location.href='emp_profile.php?user=$username'</script>";
?>