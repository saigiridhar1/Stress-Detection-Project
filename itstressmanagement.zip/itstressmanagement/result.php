<?php include 'inc/config.php';  ?>
<?php include 'inc/top.php';      ?>


<div class="block">
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>
<?php include 'inc/bottom.php'; // Close body and html tags ?>